/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : tiyu

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2022-07-02 19:58:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'admin', 'admin');

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `cid` varchar(50) NOT NULL,
  `cname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '李宁');
INSERT INTO `category` VALUES ('2', '特步');
INSERT INTO `category` VALUES ('3', '安踏');
INSERT INTO `category` VALUES ('4', '贵人鸟');
INSERT INTO `category` VALUES ('5', '鸿星尔克');

-- ----------------------------
-- Table structure for orderitem
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `itemid` varchar(50) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `pid` varchar(32) DEFAULT NULL,
  `oid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`itemid`),
  KEY `fk_0001` (`pid`),
  KEY `fk_0002` (`oid`),
  CONSTRAINT `fk_0001` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`),
  CONSTRAINT `fk_0002` FOREIGN KEY (`oid`) REFERENCES `orders` (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderitem
-- ----------------------------
INSERT INTO `orderitem` VALUES ('04bbec59-550d-49c5-8e27-d1226a049123', '1', '1299', '1', '30d0a2ff-e3de-4662-ba60-fc40852d0495');
INSERT INTO `orderitem` VALUES ('05e28b58-dea1-4565-af3d-b96c9de18c7f', '1', '2599', '10', '410bbb89-8172-4ac6-bcda-5012bced4d30');
INSERT INTO `orderitem` VALUES ('12fc0bc7-2af7-456c-83fb-bf9f9c1f47ab', '1', '2599', '10', '4245b065-3c24-43d5-a77c-6e62cd913deb');
INSERT INTO `orderitem` VALUES ('16d00eaf-9f59-47ac-b1fc-d76acf82dcab', '1', '2599', '10', '96a38d77-c5c0-4142-b586-55856ce165f8');
INSERT INTO `orderitem` VALUES ('16def680-7b7c-4ba9-84f3-e48782b3ddc9', '2', '2598', '1', '83d73d26-0afc-4d25-96c2-02f9719a0f63');
INSERT INTO `orderitem` VALUES ('25f823bd-adcd-4ccc-9bf0-5152a83538d1', '1', '1299', '1', 'c5622699-9de2-48b6-a918-d852a387afb1');
INSERT INTO `orderitem` VALUES ('26b2ae1d-ca68-496d-aaba-360a65760010', '2', '5198', '10', '8d6eb00f-d88d-477d-9cbf-8b5f9e5fbb4a');
INSERT INTO `orderitem` VALUES ('284e1d83-d768-4fe3-b2f6-8502ebf66c4a', '1', '1299', '1', 'eb81be05-dc7b-490d-aeea-a243b5791df3');
INSERT INTO `orderitem` VALUES ('2918fe3a-26b2-40c5-963f-88b4c4a42602', '1', '1299', '1', '60c8cbe7-c51f-411c-942c-d7930a2e302c');
INSERT INTO `orderitem` VALUES ('30043f61-83af-41b2-8c0e-0312c2537642', '1', '1299', '1', 'fbfe0c70-bdd2-4d3b-bd95-d985db08b0ec');
INSERT INTO `orderitem` VALUES ('35ad1717-8d80-4b2e-ab56-055a7d4f6be3', '1', '1299', '1', 'f9f008b5-6d15-420f-b922-4b9bafcc6c30');
INSERT INTO `orderitem` VALUES ('40ed89be-7910-434b-b1c8-4ccf98701519', '1', '2599', '10', 'aecf14b3-5e8b-48e0-b0cc-7476e398371b');
INSERT INTO `orderitem` VALUES ('428ecabd-1ee7-453d-98c1-b390455ac6e1', '1', '1299', '1', 'ab7acd2f-a9b9-4b88-9910-5e884e40770c');
INSERT INTO `orderitem` VALUES ('49c9871a-492f-4326-be04-71f36a0728ea', '1', '2599', '10', '29bc7b29-3d0b-4d68-b490-83b74a2878ed');
INSERT INTO `orderitem` VALUES ('4e8b80c9-0106-45c8-a730-d763d4e96482', '1', '1299', '1', 'b59052c3-6e87-4cc3-8072-47be0e1f6bbf');
INSERT INTO `orderitem` VALUES ('51d1acf0-8f9f-41ff-a596-73ea65413d6b', '2', '5198', '10', 'ca62554b-0d11-4ca4-9d7c-268871c685bc');
INSERT INTO `orderitem` VALUES ('5b0c7b55-86ab-401c-ab9e-de4a030880e5', '1', '1299', '1', '3c65f170-c0e1-4a7b-af23-bdf2b6353f1c');
INSERT INTO `orderitem` VALUES ('5b81fb78-90e0-4db6-bd28-111111635ba2', '1', '2599', '10', '40d09457-ed08-43e4-b62e-bb01ff732b6e');
INSERT INTO `orderitem` VALUES ('7137ec33-6ad5-416a-9e7a-b8f8f1e8d002', '2', '2598', '1', '96a38d77-c5c0-4142-b586-55856ce165f8');
INSERT INTO `orderitem` VALUES ('7b746843-49c0-4842-a65c-60e5a21e6ba6', '3', '11997', '17', '2e2b39b0-a5ef-4d70-841b-eeaa1fae999e');
INSERT INTO `orderitem` VALUES ('7d2f47cb-60a0-4d6f-9ddc-4dad34affdf7', '1', '2298', '11', '2e2b39b0-a5ef-4d70-841b-eeaa1fae999e');
INSERT INTO `orderitem` VALUES ('932ddfa4-522a-42a6-b374-8b1175d8bd20', '2', '2598', '1', '7d3f9603-5463-4197-9069-d87a33334f34');
INSERT INTO `orderitem` VALUES ('9c301859-09ec-4f79-8ca7-4cd8c1030c43', '1', '1299', '1', '656d1970-abf6-4ec7-b146-93fef6f95a71');
INSERT INTO `orderitem` VALUES ('c0a209f7-3add-438f-8104-d0eea27b6a5a', '1', '1299', '1', 'fe49d0c9-f076-4222-b145-b2bd951b2a4d');
INSERT INTO `orderitem` VALUES ('c130cef2-d14f-4a4f-a832-edc84b8688e6', '1', '2599', '10', '62bc5b8a-3431-411e-9714-ad6151895849');
INSERT INTO `orderitem` VALUES ('c3d3b273-2705-4f8f-8b04-ecb9af2fe5ce', '1', '2599', '10', 'cfb73a4d-f0a0-4c12-a22b-a0675f60154a');
INSERT INTO `orderitem` VALUES ('d4669c63-1979-4550-bbb4-68032e3d7ce5', '1', '2599', '10', '17cf624c-93af-489c-b064-1425d1705a57');
INSERT INTO `orderitem` VALUES ('e44a0fe4-d942-4341-bc21-1049faf23bc2', '2', '2598', '1', 'ce949080-f473-4434-9cc1-deda7864ae7f');
INSERT INTO `orderitem` VALUES ('e44fc19a-0822-47db-b637-b0cf4ae1de07', '1', '1299', '1', '87582924-fa34-4e33-bbfd-3e4e871f72f8');
INSERT INTO `orderitem` VALUES ('ebc3c608-6cea-499f-9a2b-7bbf52651a55', '2', '5198', '10', 'bb31e315-d749-4b7e-acc1-95e59f6b46d3');
INSERT INTO `orderitem` VALUES ('fbff7eee-7a1c-48a2-824d-769a65fa3eb3', '1', '2599', '10', '8bcb4022-9375-454c-adca-1b3fc1e53e47');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `oid` varchar(50) NOT NULL,
  `ordertime` datetime DEFAULT NULL,
  `total` double DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `uid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('17cf624c-93af-489c-b064-1425d1705a57', '2022-07-01 11:40:30', '2599', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('29bc7b29-3d0b-4d68-b490-83b74a2878ed', '2022-07-01 11:39:08', '2599', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('2e2b39b0-a5ef-4d70-841b-eeaa1fae999e', '2018-09-18 18:27:48', '14295', '0', null, null, null, '373eb242933b4f5ca3bd43503c34668b');
INSERT INTO `orders` VALUES ('30d0a2ff-e3de-4662-ba60-fc40852d0495', '2022-07-01 10:28:04', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('3c65f170-c0e1-4a7b-af23-bdf2b6353f1c', '2022-07-01 09:29:30', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('40d09457-ed08-43e4-b62e-bb01ff732b6e', '2022-07-01 11:40:38', '2599', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('410bbb89-8172-4ac6-bcda-5012bced4d30', '2022-07-01 11:40:01', '2599', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('4245b065-3c24-43d5-a77c-6e62cd913deb', '2022-07-01 16:42:19', '2599', '0', '武汉', '张三丰', '13212345678', 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('60c8cbe7-c51f-411c-942c-d7930a2e302c', '2022-07-01 14:31:02', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('62bc5b8a-3431-411e-9714-ad6151895849', '2022-07-01 10:20:16', '2599', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('656d1970-abf6-4ec7-b146-93fef6f95a71', '2017-06-07 11:11:11', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('7d3f9603-5463-4197-9069-d87a33334f34', '2022-07-01 09:26:22', '2598', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('83d73d26-0afc-4d25-96c2-02f9719a0f63', '2022-07-01 09:30:23', '2598', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('87582924-fa34-4e33-bbfd-3e4e871f72f8', '2022-07-01 09:25:44', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('8bcb4022-9375-454c-adca-1b3fc1e53e47', '2017-06-25 15:55:02', '2599', '0', 'aa', 'aa', '15926434052', 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('8d6eb00f-d88d-477d-9cbf-8b5f9e5fbb4a', '2022-07-01 12:10:55', '5198', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('96a38d77-c5c0-4142-b586-55856ce165f8', '2022-07-01 14:57:17', '5197', '0', 'a', 'a', '12', 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('ab7acd2f-a9b9-4b88-9910-5e884e40770c', '2022-07-01 10:28:56', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('aecf14b3-5e8b-48e0-b0cc-7476e398371b', '2022-07-01 11:40:11', '2599', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('b59052c3-6e87-4cc3-8072-47be0e1f6bbf', '2022-07-01 09:27:38', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('bb31e315-d749-4b7e-acc1-95e59f6b46d3', '2022-07-01 12:09:33', '5198', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('c5622699-9de2-48b6-a918-d852a387afb1', '2022-07-01 10:40:34', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('ca62554b-0d11-4ca4-9d7c-268871c685bc', '2022-07-01 12:11:44', '5198', '0', '武汉', '张三丰', '13212345678', 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('ce949080-f473-4434-9cc1-deda7864ae7f', '2022-07-01 10:23:01', '2598', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('cfb73a4d-f0a0-4c12-a22b-a0675f60154a', '2022-07-01 11:41:10', '2599', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('eb81be05-dc7b-490d-aeea-a243b5791df3', '2022-07-01 16:46:06', '1299', '0', 'ww', 'ww', '13212345678', 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('f9f008b5-6d15-420f-b922-4b9bafcc6c30', '2022-07-01 10:40:16', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('fbfe0c70-bdd2-4d3b-bd95-d985db08b0ec', '2022-07-01 16:41:25', '1299', '0', '武汉', '张三丰', '13245678987', 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `orders` VALUES ('fe49d0c9-f076-4222-b145-b2bd951b2a4d', '2022-07-01 10:22:52', '1299', '0', null, null, null, 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `pid` varchar(50) NOT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `market_price` double DEFAULT NULL,
  `shop_price` double DEFAULT NULL,
  `pimage` varchar(200) DEFAULT NULL,
  `pdate` date DEFAULT NULL,
  `is_hot` int(11) DEFAULT NULL,
  `pdesc` varchar(255) DEFAULT NULL,
  `pflag` int(11) DEFAULT NULL,
  `cid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `sfk_0001` (`cid`),
  CONSTRAINT `sfk_0001` FOREIGN KEY (`cid`) REFERENCES `category` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('1', '体育用品11', '139', '129', 'products/01.png', '2022-07-02', '1', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('10', '体育用品113', '269', '259', 'products/02.png', '2015-11-02', '1', '体育用品', '0', '2');
INSERT INTO `product` VALUES ('11', '体育用品1123', '239', '229', 'products/03.png', '2015-11-02', '1', '体育用品', '0', '2');
INSERT INTO `product` VALUES ('12', '体育用品112333', '189', '179', 'products/04.png', '2015-11-02', '0', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('13', '体育用品444', '259', '249', 'products/05.png', '2015-11-02', '1', '体育用品', '0', '3');
INSERT INTO `product` VALUES ('14', '体育用品11567', '189', '179', 'products/06.png', '2015-11-02', '0', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('15', '体育用品11(A1586)', '439', '428', 'products/07.png', '2015-11-02', '1', '体育用品', '0', '2');
INSERT INTO `product` VALUES ('15e1638b-0d12-46a3-bc6b-3811a6324bc4', '体育用品11ddd', '22', '11', 'products/08.png', '2022-07-01', '1', 'ddd', '0', '2');
INSERT INTO `product` VALUES ('16', '体育用品11455', '420', '408', 'products/01.png', '2015-11-03', '0', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('17', '体育用品1135', '409', '399', 'products/02.png', '2015-11-02', '0', '体育用品', '0', '2');
INSERT INTO `product` VALUES ('18', '体育用品1122', '359', '349', 'products/03.png', '2015-11-02', '0', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('19', '体育用品11345', '159', '146', 'products/04.png', '2015-11-02', '1', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('2', '体育用品909', '289', '269', 'products/05.png', '2015-11-05', '1', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('20', '体育用品909222', '649', '549', 'products/01.png', '2015-11-02', '0', '体育用品', '0', '5');
INSERT INTO `product` VALUES ('21', '体育用品90922', '109', '99', 'products/02.png', '2015-11-02', '0', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('22', '体育用品456', '209', '199', 'products/03.png', '2015-11-02', '1', '体育用品', '0', '1');
INSERT INTO `product` VALUES ('23', '体育用品566', '179', '169', 'products/01.png', '2015-11-09', '1', '体育用品', '0', '1');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` varchar(64) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('373eb242933b4f5ca3bd43503c34668b', 'ccc', 'ccc', 'aaa', 'bbb@store.com', '15723689921', '2015-11-04', '男', '0', '9782f3e837ff422b9aee8b6381ccf927bdd9d2ced10d48f4ba4b9f187edf7738');
INSERT INTO `user` VALUES ('3ca76a75e4f64db2bacd0974acc7c897', 'bb', 'bb', '张三', 'bbb@store.com', '15723689921', '1990-02-01', '男', '0', '1258e96181a9457987928954825189000bae305094a042d6bd9d2d35674684e6');
INSERT INTO `user` VALUES ('62145f6e66ea4f5cbe7b6f6b954917d3', 'cc', 'cc', '张三', 'bbb@store.com', '15723689921', '2015-11-03', '男', '0', '19f100aa81184c03951c4b840a725b6a98097aa1106a4a38ba1c29f1a496c231');
INSERT INTO `user` VALUES ('6de59778-5b89-42f1-a232-b56b8dd09c42', null, 'lisi', 'æå', 'yinyancheng161@163.com', null, '2000-02-07', null, '0', '6de59778-5b89-42f1-a232-b56b8dd09c42');
INSERT INTO `user` VALUES ('76638486-e12d-4986-950f-47222a60f646', null, 'zhangwuji4', '尹燕成', 'yinyancheng163@163.com', null, '2000-01-01', null, '1', '76638486-e12d-4986-950f-47222a60f646');
INSERT INTO `user` VALUES ('8250d5eb-0411-4dc8-b724-3741a94f529b', null, 'www', '尹燕成', 'yinyancheng160@163.com', null, '1995-07-02', '男', '1', '8250d5eb-0411-4dc8-b724-3741a94f529b');
INSERT INTO `user` VALUES ('943418c5-4007-43fd-a767-511983367e83', null, 'wangwu', 'æå', 'yinyancheng161@163.com', null, '2000-02-07', null, '0', '943418c5-4007-43fd-a767-511983367e83');
INSERT INTO `user` VALUES ('aa75d63c-be24-47b0-9896-16671a2a0ab5', null, 'yinyancheng', 'å°¹çæ', 'yinyancheng162@163.com', null, '1995-05-04', null, '0', 'aa75d63c-be24-47b0-9896-16671a2a0ab5');
INSERT INTO `user` VALUES ('acb3f66b-9037-400a-8c83-480faa1830ba', null, 'zhangwuji2', '尹燕成', 'yinyancheng161@163.com', null, '1995-01-05', null, '0', 'acb3f66b-9037-400a-8c83-480faa1830ba');
INSERT INTO `user` VALUES ('bdc02a9b-758c-46f4-a1a5-ed6df55d1351', null, 'zhangsan', 'zhangsan', 'zhangsan@163.com', null, '2000-02-07', null, '0', 'bdc02a9b-758c-46f4-a1a5-ed6df55d1351');
INSERT INTO `user` VALUES ('c0fad34b-0813-48de-93f9-11b494a44fd8', null, 'zhangwuji1', '张无忌', 'yinyancheng161@163.com', null, null, null, '1', 'c0fad34b-0813-48de-93f9-11b494a44fd8');
INSERT INTO `user` VALUES ('c95b15a864334adab3d5bb6604c6e1fc', 'bbb', 'bbb', '老王', 'bbb@store.com', '15712344823', '2000-02-01', '男', '0', '71a3a933353347a4bcacff699e6baa9c950a02f6b84e4f6fb8404ca06febfd6f');
INSERT INTO `user` VALUES ('d00a6328-9be8-461c-9370-88f5751e4db6', null, 'ddd', '尹燕成', 'yinyancheng160@163.com', null, '1995-07-02', '男', '0', 'd00a6328-9be8-461c-9370-88f5751e4db6');
INSERT INTO `user` VALUES ('d6687307-715e-4c48-9aa6-d4a6d5206672', 'zhangwuji', 'zhangwuji', 'å¼ æ å¿', '1399491757@qq.com', null, '1995-01-01', null, '1', 'd6687307-715e-4c48-9aa6-d4a6d5206672');
INSERT INTO `user` VALUES ('e32acccb-171d-4bd1-80f0-f62c07aa4312', 'wangwu1', 'wangwu1', 'å°¹çæ', 'yinyancheng160@163.com', null, '2000-01-01', null, '0', 'e32acccb-171d-4bd1-80f0-f62c07aa4312');
INSERT INTO `user` VALUES ('f38e7a95-c894-4f9d-8eea-4d7afabe3359', 'aa', 'aa', 'æå', 'yinyancheng161@163.com', null, '2000-02-07', null, '0', 'f38e7a95-c894-4f9d-8eea-4d7afabe3359');
INSERT INTO `user` VALUES ('f55b7d3a352a4f0782c910b2c70f1ea4', 'aaa', 'aaa', '小王', 'aaa@store.com', '15712344823', '2000-02-01', '男', '1', null);
